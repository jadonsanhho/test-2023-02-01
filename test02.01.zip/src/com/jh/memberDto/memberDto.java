package com.jh.memberDto;

public class memberDto {
	public static String ID ;
	public static String PW ;
	public static String Name ;
	public static int Point ;
	
	public memberDto(String Id, String Pw, String name, int point) {
		ID = Id;
		PW = Pw;
		Name = name;
		Point = point;
	}

	public static String getID() {
		return ID;
	}

	public void setID(String Id) {
		ID = Id;
	}

	public static String getPW() {
		return PW;
	}

	public void setPW(String Pw) {
		PW = Pw;
	}

	public static String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public static int getPoint() {
		return Point;
	}

	public void setPoint(int point) {
		Point = point;
	}

	
	
	
}
