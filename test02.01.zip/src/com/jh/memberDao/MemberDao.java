package com.jh.memberDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.jh.memberDto.memberDto;

import DBConnecton.DBConnection;


public class MemberDao {
	ArrayList<MemberDao> memberList = new ArrayList<MemberDao>();
	
	public void memberSearch() throws Exception{
		Connection conn = DBConnection.getConnection();
		
		String sql = "SELECT * FROM member where id = ? ";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1,memberDto.getID());
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			memberDto.ID = (rs.getString("Id"));
			memberDto.PW = (rs.getString("Pw"));
			memberDto.Name = (rs.getString("Name"));
			memberDto.Point = (rs.getInt("Point"));
		}
		rs.close();
		pstmt.close();
		conn.close();
	}
	private static void add(ArrayList<MemberDao> memberList2) {
		// TODO Auto-generated method stub
		
	}
	public void signUp() throws Exception{
		Connection conn = DBConnection.getConnection();
		
		String sql = "insert into member (id,pw,name,point) VALUES(?,?,?,?)";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1,memberDto.getID());
		pstmt.setString(2,memberDto.getPW());
		pstmt.setString(3,memberDto.getName());
		pstmt.setInt(4,memberDto.getPoint());
		pstmt.executeUpdate();
		
		MemberDao.add(memberList);
		
		pstmt.close();
		conn.close();
	}
	public boolean logincheck(String Id , String Pw) throws Exception{
		Connection conn = DBConnection.getConnection();
		boolean result = false;
		String sql = "SELECT * FROM member (id,pw) WHERE ID = ? AND PW = ? ";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1,memberDto.getID());
		pstmt.setString(2,memberDto.getPW());
		ResultSet rs = pstmt.executeQuery();
		
		rs.close();
		pstmt.close();
		conn.close();
		return result;
	}

}
